
<?php
	include('inc/header.php');
?>

<title>LANYU | About</title>
<?php 
    include('inc/parallax.php');
 ?>
     <?php 
    include ('inc/preloader.php');
  ?>
<section class="runway-section animated fadeIn animated fadeIn">

	<h1>Ready-to-Wear S/S 2017</h1>
	<h4>at New York Fashion Week</h4>
    <div class="runway-buttons">
        <a href="runway5.php" class="btn btn-large waves-effect waves-light white black-text">Previous</a>
        <a href="runway2.php" class="btn btn-large waves-effect waves-light white black-text right">Next</a>
    </div>
	<div class="row collection-grid">
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/XoSfMHb.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/cxQHtGE.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/cKMJjlf.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/4F46Gzg.jpg" class="responsive-img materialboxed" width="300">
    </div>
 <!--    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/IgnlnCO.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/bO8nQMD.jpg" class="responsive-img materialboxed" width="300">
    </div> -->
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/g2swT7e.jpg" class="responsive-img materialboxed" width="300">
    </div>
<!--     <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/zC3fast.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/jE27pcL.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/TdADULX.jpg" class="responsive-img materialboxed" width="300">
    </div> -->
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/1FZOwKM.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/Q6iXcu0.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/zY0IUUt.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/b8AZoOD.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/pd4RwOT.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/UJYtxfC.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/tdUXqcv.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/qtT2HQJ.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/XghR19s.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/TcnFoCq.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/rZhg6vb.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/V8AJLqn.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/HXCJOV2.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/gK8MGJP.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/cydkLwN.jpg" class="responsive-img materialboxed" width="300">
    </div>
    <div class="col s4 m3 l2">
        <img src="http://i.imgur.com/wOK10f4.jpg" class="responsive-img materialboxed" width="300">
    </div>

</div>
	
</section>



<?php
	include('inc/footer.php');
?>
        <footer class="page-footer grey lighten-5">
          <div class="footer-copyright grey lighten-4">
            <div class="container grey-text text-darken-4">
            © 2016 LANYU Couture Inc.
            <ul class="right">
            	<li><i class="fa fa-instagram grey-text text-darken-4 "></i></li>
            	<li><i class="fa fa-facebook grey-text text-darken-4 "></i></li>
                <li><i class="fa fa-pinterest grey-text text-darken-4 "></i></li>
                <li><i class="fa fa-weibo grey-text text-darken-4 "></i></li>
                <li><i class="fa fa-wechat grey-text text-darken-4 "></i></li>
            </ul>
            </div>
          </div>
        </footer>
<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>
<script src="https://use.fontawesome.com/570079994e.js"></script>
<script type="text/javascript" src="../js/loader.js"></script>
<script type="text/javascript" src="../js/carousel.js"></script>
<script type="text/javascript" src="../js/map.js"></script>
<script type="text/javascript" src="../js/index.js"></script>

</body>
</html>